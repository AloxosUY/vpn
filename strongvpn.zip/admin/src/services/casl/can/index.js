import { createCanBoundTo } from '@casl/react';
import ability from '../ability';

export default createCanBoundTo(ability);
