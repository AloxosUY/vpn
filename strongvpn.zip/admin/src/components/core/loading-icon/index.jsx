import {
  LoadingOutlined,
} from '@ant-design/icons';
import React from "react";

export const LoadingIcon = () => <LoadingOutlined loop={true}/>
